var texto2 = '<h2>Bem vindo(a) ao mundo Java Script.</h2>';
//document.write(texto2);

function somaNumeros(num1, num2){
    var soma = num1 + num2;
    return soma;
}